from turtle import Turtle, Screen
ALIGNMENT = "center"
FONT = ("Arial", 24, "normal")

class Scoreboard(Turtle):

    def __init__(self):

        super().__init__()

        # Set HS to contents of file
        with open("data.txt") as score_file:
            high_score = int(score_file.read())

        self.score = 0
        self.high_score = high_score
        self.hideturtle()
        self.penup()
        self.color("white")
        self.goto(0, 260)

    def output_scoreboard(self):

        self.clear()
        self.write(f"Score: {self.score} High Score: {self.high_score}", align = ALIGNMENT, font = FONT)

    def add_to_score(self):

        self.score += 1
        #self.clear()
        self.output_scoreboard()

    def reset_scoreboard(self):

        if self.score > self.high_score:

            self.high_score = self.score

            # Update HS
            with open("data.txt", mode="w") as score_file:
                score_file.write(str(self.high_score))

        # Reset score back to 0
        self.score = 0

        # Update the scoreboard
        self.output_scoreboard()

    # def game_over(self):
    #     self.goto(0, 0)
    #     self.write("Game Over!", align = ALIGNMENT,  font = FONT)

