from turtle import Turtle
import random

# Inherit from Turtle Class
class Food(Turtle):

    def __init__(self):

        # Calls contructor of the super class. (Turtle)
        super().__init__()

        # Now we can use the Turtle classes attributes/methods within our Food class
        # without the need to crate an object/instance of Turtle
        self.shape("circle")
        self.penup()
        self.shapesize(stretch_len = 0.5, stretch_wid = 0.5)
        self.color("purple")
        self.speed("fastest")
        random_x = random.randint(-280, 280)
        random_y = random.randint(-280, 280)
        self.goto(random_x, random_y)


    def new_position(self):

        random_x = random.randint(-280, 280)
        random_y = random.randint(-280, 280)
        self.goto(random_x, random_y)